# nlptosql2

with session
