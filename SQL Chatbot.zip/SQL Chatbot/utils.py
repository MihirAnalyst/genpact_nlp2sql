import pymssql
import json
from urllib.parse import quote_plus

with open("JSON\db_details.json", 'r') as f:
    db_creds = json.load(f)

def get_connection_pymysql():
    print('get_connection_pymysql called ----------------')
    db_user=db_creds['db_user']
    db_password=db_creds['db_password']
    db_host=db_creds['db_host']
    db_port=db_creds['db_port']
    db_name=db_creds['db_name']
    tables=eval(db_creds['tables'])
    encoded_password = quote_plus(db_password)
    conn = pymssql.connect(database=db_name,host=db_host,user=db_user,password=encoded_password,as_dict=True,port=db_port)
    print('End get_connection_pymysql')
    return conn,tables

def getTableSchema(conn,tablelist):
    print('getTableSchema called----------------')
    #db_name='Chinook'
    #tablelist=list(structure[db_name]['dbo']['tables'].keys())
    #print('getTableSchema called----------------')
    schema_defn={}
    # for folder in list(structure[db_name].keys()):
    #     for sub_folder in list(structure[db_name][folder].keys()):
    #         tablelist=list(structure[db_name][folder][sub_folder].keys())
    tablelist=eval(db_creds['tables'])
    print('Table _list:',tablelist)
    for i in tablelist:
        #print('Table: ',i)
        # column_list=list(structure[db_name][folder][sub_folder][i].keys())
        # print(column_list)
        cursor=conn.cursor()
        cursor.execute(f"select COLUMN_NAME, DATA_TYPE, table_schema from INFORMATION_SCHEMA.COLUMNS where TABLE_NAME= '{i}'")
        
        columnnames2=cursor.fetchall()
        columnnames=columnnames2
        cursor.close()
        
        #Code to Filter Columns
        # for col in columnnames2:
        #     if col['COLUMN_NAME'] in column_list:
        #         columnnames.append(col)
                

        #print('Column Names:', columnnames)
        schemaname=columnnames[0]['table_schema']
        cursor=conn.cursor()
        column_details={}
        for j in columnnames:
            column_details[j['COLUMN_NAME']]=j['DATA_TYPE']
        
        schema_defn[schemaname+'.'+i]=column_details
    cursor.close()
    return schema_defn