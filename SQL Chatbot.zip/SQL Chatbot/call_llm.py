import pandas as pd
import os
import json
#from langchain_community.chat_models import ChatOpenAI
from langchain_community.chat_models import ChatOpenAI
from sqlalchemy import text
import plotly.io as pio
import plotly.graph_objects as go

# Load the prompt for the new task
with open("Prompt\prompt.txt", 'r') as file:
    prompt_template = file.read()

with open("Prompt\graph_prompt.txt", 'r') as file:
    graph_prompt = file.read()

# Initialize the LLM model
print("Loading LLM Model")
os.environ["OPENAI_API_KEY"] = ""
llm_model = "gpt-3.5-turbo"
model = ChatOpenAI(temperature=1, model=llm_model)
print("Loading LLM Model Done.")


def generate_prompt(query,schema,prompt_template):
    # Replace the placeholder [USER_QUERY] with the actual user query
    new_prompt=eval(prompt_template)
    
    return new_prompt

def perform_llm_call(conn, query, schema):
    global model, prompt_template
    new_prompt = generate_prompt(query, schema ,prompt_template)
    print('-' * 40)
    print(new_prompt)
    print('-' * 40)
    print("Calling Model")
    Sql_ans = model.invoke(new_prompt)
    sql_query = Sql_ans.content.replace("\n"," ").replace("Answer","").replace(":"," ").replace('"','')
    print('Generated Query: \n',sql_query,'\n------------------------------------------------------------------')
    
    df = pd.read_sql(sql_query, conn)
    df.to_csv('Test_data.csv',index=False)

    df_structure = {col: str(df[col].dtype) for col in df.columns}
    final_graph_prompt=graph_prompt+f'\n\nUser Query:\n{query}\n\nDataframe Columns:\n{df_structure}\n\nOUTPUT:'
    print('final_graph_prompt: \n',final_graph_prompt,'\n------------------------------------------------------------------')

    Sql_graph = model.invoke(graph_prompt)
    img_code = Sql_graph.content.replace("python","").replace("`","")
    img_code+='\ngraph_object=analyze_g(data)'
    print('Graph Code:\n',img_code,'\n------------------------------------------------------------------')

    # generated_response = generated_response.content
    # print(generated_response)
    print("Calling Model Done")
    #generated_response = generated_response.replace('<end of code>', '').strip()

    compile_exec = {'data':df}
    try:
        exec(img_code, compile_exec)
        print('\n**********************Code Executed.*******************\n')
        g1 = compile_exec
        print(g1.keys())
        new_graph = pio.to_html(g1['graph_object'], full_html=False,include_plotlyjs=False,config={'responsive': True},default_height="338px",default_width="100%",div_id="mygraph")
        new_graph=g1['graph_object']
        return(sql_query,df,new_graph,img_code)
    except Exception as e:
        print('Graph Code Execution Failed:\n',e)
        return(sql_query,df,None,img_code)
    try:
        exec(generated_response, compile_exec)
        result_msg, result_data, graph_img = compile_exec['message'], compile_exec['analyzed_df'], compile_exec['graph']
        return result_msg, result_data, graph_img, generated_response
    except Exception as e:
        msg = f"I'm sorry, I encountered an issue while trying to process your question : {str(e)} . Could you please try rephrasing it or provide more context?"
        return msg, None, None, generated_response


